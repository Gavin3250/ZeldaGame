import java.util.Scanner;

public class Game {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Player player = new Player();
        LocationManager locationManager = new LocationManager();
        BattleSystem battleSystem = new BattleSystem(player);
        Spawner spawner = new Spawner();

        boolean playing = true;

        while (playing) {
            player.reset();
            System.out.println("You are Link, a brave and loyal Knight of Hyrule. However, Hyrule is under siege by the ultimate evil Ganondorf.");
            System.out.println("Travel to all locations first while fighting enemies along the way to reach Hyrule Castle.");
            System.out.println("Where do you wish to begin your journey?");
            locationManager.displayAvailableLocations();

            while (!player.hasVisitedAllLocations()) {
                String nextLocation = locationManager.chooseLocation(input, player);
                if (nextLocation.equals("Korok Forest")) {
                    battleSystem.startBattle(new SwordsProtector());
                } else if (nextLocation.equals("Hyrule Castle")) {
                    battleSystem.startBattle(new Ganondorf());
                    System.out.println("The ultimate evil Ganondorf is defeated. Hyrule is now at peace, having been saved by the ultimate hero, Link. Congratulations!");
                    System.out.println("If you would like to play again, type y. Otherwise, type n");
                    String again = input.nextLine();
                    if (again.equalsIgnoreCase("n")) {
                        playing = false;
                    }
                    break;
                } else {
                    for (int i = 0; i < 3; i++) {
                        Enemy nextEnemy = spawner.getNextEnemy();
                        battleSystem.startBattle(nextEnemy);
                        if (!player.isAlive()) {
                            System.out.println("You have been defeated. Game Over.");
                            playing = false;
                            break;
                        }
                    }
                    if (player.isAlive()) {
                        locationManager.arriveAtLocation(nextLocation, player);
                    }
                }
            }
        }

        System.out.println("Thank you for playing!");
        input.close();
    }
}
